package aquarium.models.decorations;

public class Ornament extends BaseDecoration {
    public Ornament() {
        super(1, 5);
    }
}
