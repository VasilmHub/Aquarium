package aquarium.models.aquariums;

public class SaltwaterAquarium extends BaseAquarium {
    public SaltwaterAquarium(String name) {
        super(name, 25);
    }
}
